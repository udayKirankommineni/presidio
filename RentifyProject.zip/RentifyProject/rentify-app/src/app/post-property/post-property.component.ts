import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-property',
  templateUrl: './post-property.component.html',
  styleUrls: ['./post-property.component.css']
})
export class PostPropertyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
