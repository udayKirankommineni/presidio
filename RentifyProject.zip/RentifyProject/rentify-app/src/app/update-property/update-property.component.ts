import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-property',
  templateUrl: './update-property.component.html',
  styleUrls: ['./update-property.component.css']
})
export class UpdatePropertyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
